from django.apps import AppConfig


class PurchaseitemConfig(AppConfig):
    name = 'purchaseitem'
