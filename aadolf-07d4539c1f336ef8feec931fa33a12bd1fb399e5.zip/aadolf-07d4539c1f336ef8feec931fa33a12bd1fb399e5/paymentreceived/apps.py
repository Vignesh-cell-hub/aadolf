from django.apps import AppConfig


class PaymentreceivedConfig(AppConfig):
    name = 'paymentreceived'
