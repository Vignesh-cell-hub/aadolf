from django.apps import AppConfig


class ItemformConfig(AppConfig):
    name = 'itemform'
